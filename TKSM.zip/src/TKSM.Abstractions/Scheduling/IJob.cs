﻿namespace TKSM.Abstractions.Scheduling;

public interface IJob { }
