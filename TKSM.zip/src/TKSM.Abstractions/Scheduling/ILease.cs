﻿namespace TKSM.Abstractions.Scheduling;

public interface ILease { }
