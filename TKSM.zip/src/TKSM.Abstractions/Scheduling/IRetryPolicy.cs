﻿namespace TKSM.Abstractions.Scheduling;

public interface IRetryPolicy { }
