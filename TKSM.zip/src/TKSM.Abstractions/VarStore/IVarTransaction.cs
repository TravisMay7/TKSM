﻿namespace TKSM.Abstractions.VarStore;

public interface IVarTransaction { }
