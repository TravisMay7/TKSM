﻿namespace TKSM.Abstractions.VarStore;

public interface IVarStore { }
