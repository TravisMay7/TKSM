﻿namespace TKSM.Abstractions.VarStore;

public interface IVarLayer { }
