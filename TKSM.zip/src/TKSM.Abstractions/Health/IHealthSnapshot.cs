﻿namespace TKSM.Abstractions.Health;

public interface IHealthSnapshot { }