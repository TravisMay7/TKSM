﻿namespace TKSM.Abstractions.Observability;

public interface ILogEntry { }
