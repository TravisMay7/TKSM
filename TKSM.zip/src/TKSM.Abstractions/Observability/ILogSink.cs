﻿namespace TKSM.Abstractions.Observability;

public interface ILogSink { }
