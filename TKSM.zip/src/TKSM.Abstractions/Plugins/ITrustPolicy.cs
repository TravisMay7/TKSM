﻿namespace TKSM.Abstractions.Plugins;

public interface ITrustPolicy { }
