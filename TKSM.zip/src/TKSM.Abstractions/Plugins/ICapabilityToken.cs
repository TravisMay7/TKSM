﻿namespace TKSM.Abstractions.Plugins;

public interface ICapabilityToken { }