﻿namespace TKSM.Abstractions.Plugins;

public interface IPlugin { }
