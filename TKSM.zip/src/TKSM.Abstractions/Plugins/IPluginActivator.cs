﻿namespace TKSM.Abstractions.Plugins;

public interface IPluginActivator { }
