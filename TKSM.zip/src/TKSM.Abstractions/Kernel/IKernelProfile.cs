﻿namespace TKSM.Abstractions.Kernel;

public interface IKernelProfile { }
