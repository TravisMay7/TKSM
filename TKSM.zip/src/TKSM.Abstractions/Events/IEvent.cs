﻿
namespace TKSM.Abstractions.Events;

public interface IEvent { }
