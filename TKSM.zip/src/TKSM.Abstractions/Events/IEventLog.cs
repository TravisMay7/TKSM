﻿
namespace TKSM.Abstractions.Events;

public interface IEventLog { }
