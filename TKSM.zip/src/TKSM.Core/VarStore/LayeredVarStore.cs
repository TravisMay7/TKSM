﻿namespace TKSM.Core.VarStore;

public class LayeredVarStore { }