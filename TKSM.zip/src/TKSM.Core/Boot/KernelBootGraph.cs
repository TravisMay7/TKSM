﻿namespace TKSM.Core.Boot;

internal class KernelBootGraph
{
}
