﻿namespace TKSM.Core.Observability;

public class InMemoryEventLogger { }