﻿namespace TKSM.Core.Policies;

internal class PolicyStuff
{
}
