﻿namespace TKSM.Core.Scheduling;

internal class WorkScheduler { }
