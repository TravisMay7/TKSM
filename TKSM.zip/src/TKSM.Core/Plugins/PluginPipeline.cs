﻿namespace TKSM.Core.Plugins;

public class PluginPipeline
{
}