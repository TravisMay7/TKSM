﻿namespace TKSM.Core.EventSpine;

public class InMemeoryEventLog { }
