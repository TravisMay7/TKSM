﻿namespace TKSM.Core.EventSpine;

public class ProjectionHost { }